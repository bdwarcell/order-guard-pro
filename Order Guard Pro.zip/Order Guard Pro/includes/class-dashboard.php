<?php
class Order_Guard_Pro_Dashboard {
    private $database;

    public function __construct($database) {
        $this->database = $database;
    }

    public function init() {
        add_action('wp_ajax_order_guard_pro_get_stats', [$this, 'get_stats_ajax']);
    }

    public function get_stats_ajax() {
        check_ajax_referer('order_guard_pro_nonce', 'security');

        if (!isset($_POST['start_date']) || !isset($_POST['end_date'])) {
            wp_send_json_error();
        }

        $start_date = sanitize_text_field($_POST['start_date']);
        $end_date = sanitize_text_field($_POST['end_date']);

        $attempts = $this->database->get_attempts_by_date($start_date, $end_date);
        $blocked = $this->database->get_attempts_by_date($start_date, $end_date, 'blocked');

        wp_send_json_success([
            'attempts' => $attempts,
            'blocked' => $blocked
        ]);
    }
}