<?php
class Order_Guard_Pro_Admin_Interface {
    private $database;
    private $export_import;

    public function __construct($database, $export_import) {
        $this->database = $database;
        $this->export_import = $export_import;
    }

    public function init() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('admin_init', [$this, 'handle_export_import']);
        add_action('admin_init', [$this, 'handle_whitelist_actions']);
    }

    public function add_admin_menu() {
        $icon_url = file_exists(ORDER_GUARD_PRO_PLUGIN_DIR . 'assets/images/icon-128x128.png') 
            ? plugins_url('assets/images/icon-128x128.png', ORDER_GUARD_PRO_PLUGIN_FILE)
            : 'dashicons-shield-alt';

        add_menu_page(
            __('Order Guard Pro', 'order-guard-pro'),
            __('Order Guard Pro', 'order-guard-pro'),
            'manage_options',
            'order-guard-pro',
            [$this, 'render_admin_page'],
            $icon_url,
            56
        );

        add_submenu_page(
            'order-guard-pro',
            __('Dashboard', 'order-guard-pro'),
            __('Dashboard', 'order-guard-pro'),
            'manage_options',
            'order-guard-pro-dashboard',
            [$this, 'render_dashboard_page']
        );
    }

    public function register_settings() {
        register_setting('order_guard_pro_settings', 'order_guard_pro_threshold');
        register_setting('order_guard_pro_settings', 'order_guard_pro_block_duration');
        register_setting('order_guard_pro_settings', 'order_guard_pro_enable_phone_check');
        register_setting('order_guard_pro_settings', 'order_guard_pro_enable_email_check');
        register_setting('order_guard_pro_settings', 'order_guard_pro_blocked_message');

        add_settings_section(
            'order_guard_pro_main',
            __('Main Settings', 'order-guard-pro'),
            [$this, 'render_settings_section'],
            'order-guard-pro'
        );

        add_settings_field(
            'order_guard_pro_threshold',
            __('Order Attempt Threshold', 'order-guard-pro'),
            [$this, 'render_threshold_field'],
            'order-guard-pro',
            'order_guard_pro_main'
        );

        add_settings_field(
            'order_guard_pro_block_duration',
            __('Block Duration (hours)', 'order-guard-pro'),
            [$this, 'render_block_duration_field'],
            'order-guard-pro',
            'order_guard_pro_main'
        );

        add_settings_field(
            'order_guard_pro_enable_phone_check',
            __('Enable Phone Number Check', 'order-guard-pro'),
            [$this, 'render_phone_check_field'],
            'order-guard-pro',
            'order_guard_pro_main'
        );

        add_settings_field(
            'order_guard_pro_enable_email_check',
            __('Enable Email Check', 'order-guard-pro'),
            [$this, 'render_email_check_field'],
            'order-guard-pro',
            'order_guard_pro_main'
        );

        add_settings_field(
            'order_guard_pro_blocked_message',
            __('Blocked Message', 'order-guard-pro'),
            [$this, 'render_blocked_message_field'],
            'order-guard-pro',
            'order_guard_pro_main'
        );
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'order-guard-pro'));
        }

        if (isset($_GET['action']) && isset($_GET['id']) && check_admin_referer('order_guard_pro_action')) {
            $id = intval($_GET['id']);
            
            if ($_GET['action'] === 'unblock') {
                $this->database->unblock_item($id);
                $this->database->add_notification(
                    'unblock',
                    sprintf(__('Unblocked item with ID %d', 'order-guard-pro'), $id)
                );
                add_settings_error(
                    'order_guard_pro_messages',
                    'order_guard_pro_message',
                    __('Item has been unblocked.', 'order-guard-pro'),
                    'updated'
                );
            }
        }

        settings_errors('order_guard_pro_messages');

        $blocked_items = $this->database->get_blocked_items();
        $whitelist_items = $this->database->get_whitelist_items();

        include ORDER_GUARD_PRO_PLUGIN_DIR . 'templates/admin-page.php';
    }

    public function render_dashboard_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'order-guard-pro'));
        }

        $today_attempts = $this->database->get_attempts_count('today');
        $today_blocked = $this->database->get_attempts_count('today', 'blocked');
        $month_attempts = $this->database->get_attempts_count('month');
        $month_blocked = $this->database->get_attempts_count('month', 'blocked');
        $year_attempts = $this->database->get_attempts_count('year');
        $year_blocked = $this->database->get_attempts_count('year', 'blocked');

        include ORDER_GUARD_PRO_PLUGIN_DIR . 'templates/dashboard.php';
    }

    public function handle_export_import() {
        if (!isset($_POST['order_guard_pro_export']) && !isset($_POST['order_guard_pro_import'])) {
            return;
        }

        check_admin_referer('order_guard_pro_export_import');

        if (isset($_POST['order_guard_pro_export'])) {
            $this->export_import->export_blocked_list_to_csv();
        }

        if (isset($_POST['order_guard_pro_import']) && !empty($_FILES['blocked_list_csv']['tmp_name'])) {
            $file = $_FILES['blocked_list_csv']['tmp_name'];
            $result = $this->export_import->import_blocked_list_from_csv($file);

            if (is_wp_error($result)) {
                add_settings_error(
                    'order_guard_pro_messages',
                    'order_guard_pro_message',
                    $result->get_error_message(),
                    'error'
                );
            } else {
                $this->database->add_notification(
                    'import',
                    sprintf(__('Imported %d items, skipped %d duplicates', 'order-guard-pro'), $result['imported'], $result['skipped'])
                );
                add_settings_error(
                    'order_guard_pro_messages',
                    'order_guard_pro_message',
                    sprintf(__('Successfully imported %d items, skipped %d duplicates.', 'order-guard-pro'), $result['imported'], $result['skipped']),
                    'updated'
                );
            }
        }
    }

    public function handle_whitelist_actions() {
        if (!isset($_POST['order_guard_pro_add_to_whitelist']) && !isset($_GET['action']) || $_GET['action'] !== 'remove_from_whitelist') {
            return;
        }

        if (isset($_POST['order_guard_pro_add_to_whitelist'])) {
            check_admin_referer('order_guard_pro_whitelist');

            $ip = !empty($_POST['whitelist_ip']) ? sanitize_text_field($_POST['whitelist_ip']) : null;
            $phone = !empty($_POST['whitelist_phone']) ? sanitize_text_field($_POST['whitelist_phone']) : null;
            $email = !empty($_POST['whitelist_email']) ? sanitize_email($_POST['whitelist_email']) : null;
            $notes = !empty($_POST['whitelist_notes']) ? sanitize_text_field($_POST['whitelist_notes']) : '';

            if ($ip || $phone || $email) {
                $result = $this->database->add_to_whitelist($ip, $phone, $email, $notes);
                
                if ($result) {
                    $this->database->add_notification(
                        'whitelist',
                        __('Added new item to whitelist', 'order-guard-pro')
                    );
                    add_settings_error(
                        'order_guard_pro_messages',
                        'order_guard_pro_message',
                        __('Item has been added to whitelist.', 'order-guard-pro'),
                        'updated'
                    );
                }
            }
        }

        if (isset($_GET['action']) && $_GET['action'] === 'remove_from_whitelist' && isset($_GET['id']) && check_admin_referer('order_guard_pro_action')) {
            $id = intval($_GET['id']);
            $result = $this->database->remove_from_whitelist($id);
            
            if ($result) {
                $this->database->add_notification(
                    'whitelist',
                    sprintf(__('Removed item with ID %d from whitelist', 'order-guard-pro'), $id)
                );
                add_settings_error(
                    'order_guard_pro_messages',
                    'order_guard_pro_message',
                    __('Item has been removed from whitelist.', 'order-guard-pro'),
                    'updated'
                );
            }
        }
    }

    public function render_settings_section() {
        echo '<p>' . __('Configure the basic settings for Order Guard Pro.', 'order-guard-pro') . '</p>';
    }

    public function render_threshold_field() {
        $threshold = get_option('order_guard_pro_threshold', 5);
        echo '<input type="number" id="order_guard_pro_threshold" name="order_guard_pro_threshold" value="' . esc_attr($threshold) . '" min="1" class="small-text" />';
        echo '<p class="description">' . __('Number of order attempts before blocking.', 'order-guard-pro') . '</p>';
    }

    public function render_block_duration_field() {
        $duration = get_option('order_guard_pro_block_duration', 24);
        echo '<input type="number" id="order_guard_pro_block_duration" name="order_guard_pro_block_duration" value="' . esc_attr($duration) . '" min="1" class="small-text" />';
        echo '<p class="description">' . __('Hours to look back for order attempts.', 'order-guard-pro') . '</p>';
    }

    public function render_phone_check_field() {
        $enabled = get_option('order_guard_pro_enable_phone_check', '1');
        echo '<input type="checkbox" id="order_guard_pro_enable_phone_check" name="order_guard_pro_enable_phone_check" value="1" ' . checked(1, $enabled, false) . ' />';
        echo '<label for="order_guard_pro_enable_phone_check">' . __('Enable phone number checking', 'order-guard-pro') . '</label>';
    }

    public function render_email_check_field() {
        $enabled = get_option('order_guard_pro_enable_email_check', '1');
        echo '<input type="checkbox" id="order_guard_pro_enable_email_check" name="order_guard_pro_enable_email_check" value="1" ' . checked(1, $enabled, false) . ' />';
        echo '<label for="order_guard_pro_enable_email_check">' . __('Enable email address checking', 'order-guard-pro') . '</label>';
    }

    public function render_blocked_message_field() {
        $message = get_option('order_guard_pro_blocked_message', 
            __('We have detected suspicious order attempts from your information. For security reasons, additional orders cannot be placed at this time.', 'order-guard-pro'));
        echo '<textarea id="order_guard_pro_blocked_message" name="order_guard_pro_blocked_message" rows="5" class="large-text">' . esc_textarea($message) . '</textarea>';
        echo '<p class="description">' . __('This message will be shown to blocked users.', 'order-guard-pro') . '</p>';
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'order-guard-pro') === false) {
            return;
        }

        wp_enqueue_style(
            'order-guard-pro-admin',
            ORDER_GUARD_PRO_PLUGIN_URL . 'assets/css/admin.css',
            [],
            ORDER_GUARD_PRO_VERSION
        );

        wp_enqueue_script(
            'order-guard-pro-admin',
            ORDER_GUARD_PRO_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            ORDER_GUARD_PRO_VERSION,
            true
        );

        if ($hook === 'order-guard-pro_page_order-guard-pro-dashboard') {
            wp_enqueue_style(
                'order-guard-pro-dashboard',
                ORDER_GUARD_PRO_PLUGIN_URL . 'assets/css/dashboard.css',
                [],
                ORDER_GUARD_PRO_VERSION
            );

            wp_enqueue_script(
                'order-guard-pro-dashboard',
                ORDER_GUARD_PRO_PLUGIN_URL . 'assets/js/dashboard.js',
                ['jquery', 'wp-util'],
                ORDER_GUARD_PRO_VERSION,
                true
            );

            wp_localize_script(
                'order-guard-pro-dashboard',
                'order_guard_pro_dashboard',
                [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('order_guard_pro_nonce'),
                    'loading_text' => __('Loading...', 'order-guard-pro'),
                    'error_text' => __('Error loading data', 'order-guard-pro'),
                    'attempts_label' => __('Attempts', 'order-guard-pro'),
                    'blocked_label' => __('Blocked', 'order-guard-pro'),
                    'chart_title' => __('Order Attempts and Blocks', 'order-guard-pro')
                ]
            );
        }
    }
}