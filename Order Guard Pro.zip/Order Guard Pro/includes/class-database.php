<?php
class Order_Guard_Pro_Database {
    private static $table_blocked = 'order_guard_pro_blocked';
    private static $table_attempts = 'order_guard_pro_attempts';
    private static $table_whitelist = 'order_guard_pro_whitelist';
    private static $table_notifications = 'order_guard_pro_notifications';

    public function init() {
        // Any initialization code
    }

    public static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $tables = [
            $wpdb->prefix . self::$table_blocked => "
                CREATE TABLE {$wpdb->prefix}order_guard_pro_blocked (
                    id bigint(20) NOT NULL AUTO_INCREMENT,
                    ip_address varchar(45),
                    phone_number varchar(20),
                    email varchar(100),
                    blocked_at datetime NOT NULL,
                    reason text,
                    is_active tinyint(1) DEFAULT 1,
                    PRIMARY KEY (id),
                    INDEX ip_index (ip_address),
                    INDEX phone_index (phone_number),
                    INDEX email_index (email)
                ) $charset_collate",
                
            $wpdb->prefix . self::$table_attempts => "
                CREATE TABLE {$wpdb->prefix}order_guard_pro_attempts (
                    id bigint(20) NOT NULL AUTO_INCREMENT,
                    ip_address varchar(45),
                    phone_number varchar(20),
                    email varchar(100),
                    attempt_time datetime NOT NULL,
                    order_data text,
                    status varchar(20) DEFAULT 'attempted',
                    PRIMARY KEY (id),
                    INDEX ip_index (ip_address),
                    INDEX phone_index (phone_number),
                    INDEX email_index (email),
                    INDEX status_index (status)
                ) $charset_collate",
                
            $wpdb->prefix . self::$table_whitelist => "
                CREATE TABLE {$wpdb->prefix}order_guard_pro_whitelist (
                    id bigint(20) NOT NULL AUTO_INCREMENT,
                    ip_address varchar(45),
                    phone_number varchar(20),
                    email varchar(100),
                    added_at datetime NOT NULL,
                    added_by bigint(20),
                    notes text,
                    PRIMARY KEY (id),
                    INDEX ip_index (ip_address),
                    INDEX phone_index (phone_number),
                    INDEX email_index (email)
                ) $charset_collate",
                
            $wpdb->prefix . self::$table_notifications => "
                CREATE TABLE {$wpdb->prefix}order_guard_pro_notifications (
                    id bigint(20) NOT NULL AUTO_INCREMENT,
                    notification_type varchar(50) NOT NULL,
                    notification_text text NOT NULL,
                    is_read tinyint(1) DEFAULT 0,
                    created_at datetime NOT NULL,
                    PRIMARY KEY (id),
                    INDEX type_index (notification_type),
                    INDEX read_index (is_read)
                ) $charset_collate"
        ];

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        foreach ($tables as $table_name => $sql) {
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
                dbDelta($sql);
            }
        }
    }

    public function log_attempt($ip, $phone, $email, $order_data = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_attempts;

        return $wpdb->insert(
            $table,
            [
                'ip_address' => $ip,
                'phone_number' => $phone,
                'email' => $email,
                'attempt_time' => current_time('mysql'),
                'order_data' => maybe_serialize($order_data)
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );
    }

    public function block_user($ip = null, $phone = null, $email = null, $reason = '') {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_blocked;

        $data = [
            'blocked_at' => current_time('mysql'),
            'reason' => $reason,
            'is_active' => 1
        ];

        if ($ip) $data['ip_address'] = $ip;
        if ($phone) $data['phone_number'] = $phone;
        if ($email) $data['email'] = $email;

        return $wpdb->insert($table, $data);
    }

    public function is_blocked($ip = null, $phone = null, $email = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_blocked;

        $conditions = [];
        $args = [];

        if ($ip) {
            $conditions[] = 'ip_address = %s';
            $args[] = $ip;
        }
        if ($phone) {
            $conditions[] = 'phone_number = %s';
            $args[] = $phone;
        }
        if ($email) {
            $conditions[] = 'email = %s';
            $args[] = $email;
        }

        if (empty($conditions)) return false;

        $query = "SELECT COUNT(*) FROM $table WHERE is_active = 1 AND (" . implode(' OR ', $conditions) . ")";
        
        return $wpdb->get_var($wpdb->prepare($query, $args)) > 0;
    }

    public function is_whitelisted($ip = null, $phone = null, $email = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_whitelist;

        $conditions = [];
        $args = [];

        if ($ip) {
            $conditions[] = 'ip_address = %s';
            $args[] = $ip;
        }
        if ($phone) {
            $conditions[] = 'phone_number = %s';
            $args[] = $phone;
        }
        if ($email) {
            $conditions[] = 'email = %s';
            $args[] = $email;
        }

        if (empty($conditions)) return false;

        $query = "SELECT COUNT(*) FROM $table WHERE " . implode(' OR ', $conditions);
        
        return $wpdb->get_var($wpdb->prepare($query, $args)) > 0;
    }

    public function add_to_whitelist($ip = null, $phone = null, $email = null, $notes = '') {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_whitelist;

        $data = [
            'added_at' => current_time('mysql'),
            'added_by' => get_current_user_id(),
            'notes' => $notes
        ];

        if ($ip) $data['ip_address'] = $ip;
        if ($phone) $data['phone_number'] = $phone;
        if ($email) $data['email'] = $email;

        return $wpdb->insert($table, $data);
    }

    public function remove_from_whitelist($id) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_whitelist;

        return $wpdb->delete($table, ['id' => $id], ['%d']);
    }

    public function get_whitelist_items() {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_whitelist;

        return $wpdb->get_results("SELECT * FROM $table ORDER BY added_at DESC");
    }

    public function get_blocked_items() {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_blocked;

        return $wpdb->get_results("SELECT * FROM $table WHERE is_active = 1 ORDER BY blocked_at DESC");
    }

    public function unblock_item($id) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_blocked;

        return $wpdb->update(
            $table,
            ['is_active' => 0],
            ['id' => $id],
            ['%d'],
            ['%d']
        );
    }

    public function add_notification($type, $text) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_notifications;

        return $wpdb->insert($table, [
            'notification_type' => $type,
            'notification_text' => $text,
            'created_at' => current_time('mysql')
        ]);
    }

    public function get_notifications($limit = 5, $unread_only = false) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_notifications;

        $query = "SELECT * FROM $table";
        $conditions = [];

        if ($unread_only) {
            $conditions[] = "is_read = 0";
        }

        if (!empty($conditions)) {
            $query .= " WHERE " . implode(' AND ', $conditions);
        }

        $query .= " ORDER BY created_at DESC LIMIT %d";
        
        return $wpdb->get_results($wpdb->prepare($query, $limit));
    }

    public function mark_notification_read($id) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_notifications;

        return $wpdb->update(
            $table,
            ['is_read' => 1],
            ['id' => $id],
            ['%d'],
            ['%d']
        );
    }

    public function get_attempts_count($period = 'today', $status = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_attempts;

        $query = "SELECT COUNT(*) FROM $table WHERE ";
        
        switch ($period) {
            case 'today':
                $query .= "DATE(attempt_time) = CURDATE()";
                break;
            case 'month':
                $query .= "YEAR(attempt_time) = YEAR(CURDATE()) AND MONTH(attempt_time) = MONTH(CURDATE())";
                break;
            case 'year':
                $query .= "YEAR(attempt_time) = YEAR(CURDATE())";
                break;
            default:
                $query .= "1=1";
        }

        if ($status) {
            $query .= $wpdb->prepare(" AND status = %s", $status);
        }

        return $wpdb->get_var($query);
    }

    public function get_attempts_by_date($start_date, $end_date, $status = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . self::$table_attempts;

        $query = $wpdb->prepare(
            "SELECT DATE(attempt_time) as attempt_date, COUNT(*) as count 
             FROM $table 
             WHERE attempt_time BETWEEN %s AND %s",
            $start_date . ' 00:00:00',
            $end_date . ' 23:59:59'
        );

        if ($status) {
            $query .= $wpdb->prepare(" AND status = %s", $status);
        }

        $query .= " GROUP BY DATE(attempt_time) ORDER BY attempt_date";

        return $wpdb->get_results($query);
    }
}