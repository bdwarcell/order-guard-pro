<?php
class Order_Guard_Pro_IP_Helper {
    public static function get_client_ip() {
        $ip_keys = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];

        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER)) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    
                    if (self::validate_ip($ip)) {
                        return $ip;
                    }
                }
            }
        }

        return $_SERVER['REMOTE_ADDR'] ?? '';
    }

    private static function validate_ip($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }

    public static function get_ip_location($ip) {
        $response = @file_get_contents("http://ip-api.com/json/{$ip}");
        
        if ($response === false) {
            return false;
        }

        $details = json_decode($response);
        
        $location = [];
        if (isset($details->city)) $location['city'] = $details->city;
        if (isset($details->regionName)) $location['region'] = $details->regionName;
        if (isset($details->country)) $location['country'] = $details->country;
        if (isset($details->isp)) $location['isp'] = $details->isp;
        
        return !empty($location) ? $location : false;
    }

    public static function anonymize_ip($ip) {
        if (strpos($ip, '.') !== false) {
            return preg_replace('/\.\d+$/', '.xxx', $ip);
        } elseif (strpos($ip, ':') !== false) {
            return preg_replace('/:[^:]+$/', ':xxxx', $ip);
        }
        return $ip;
    }
}