<?php
class Order_Guard_Pro_Notifications {
    private $database;

    public function __construct($database) {
        $this->database = $database;
    }

    public function init() {
        add_action('admin_notices', [$this, 'show_admin_notices']);
        add_action('wp_ajax_order_guard_pro_dismiss_notice', [$this, 'dismiss_notice_ajax']);
    }

    public function add($type, $text) {
        return $this->database->add_notification($type, $text);
    }

    public function show_admin_notices() {
        $notifications = $this->database->get_notifications(5, true);
        
        if (empty($notifications)) return;

        foreach ($notifications as $notification) {
            ?>
            <div class="notice notice-info is-dismissible order-guard-pro-notice" 
                 data-notification-id="<?php echo esc_attr($notification->id); ?>">
                <p><?php echo esc_html($notification->notification_text); ?></p>
            </div>
            <?php
        }
    }

    public function dismiss_notice_ajax() {
        check_ajax_referer('order_guard_pro_nonce', 'security');

        if (!isset($_POST['notification_id'])) {
            wp_send_json_error();
        }

        $notification_id = intval($_POST['notification_id']);
        $result = $this->database->mark_notification_read($notification_id);

        if ($result) {
            wp_send_json_success();
        } else {
            wp_send_json_error();
        }
    }
}