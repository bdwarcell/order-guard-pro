<?php
class Order_Guard_Pro_Export_Import {
    private $database;

    public function __construct($database) {
        $this->database = $database;
    }

    public function export_blocked_list_to_csv() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'order_guard_pro_blocked';
        $items = $wpdb->get_results("SELECT * FROM $table WHERE is_active = 1");

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="order-guard-pro-blocked-list-' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        
        // CSV header
        fputcsv($output, ['ID', 'IP Address', 'Phone Number', 'Email', 'Blocked At', 'Reason']);

        // CSV data
        foreach ($items as $item) {
            fputcsv($output, [
                $item->id,
                $item->ip_address,
                $item->phone_number,
                $item->email,
                $item->blocked_at,
                $item->reason
            ]);
        }

        fclose($output);
        exit;
    }

    public function import_blocked_list_from_csv($file) {
        global $wpdb;
        
        if (!file_exists($file)) {
            return new WP_Error('file_not_found', __('CSV file not found.', 'order-guard-pro'));
        }

        $handle = fopen($file, 'r');
        if (!$handle) {
            return new WP_Error('file_open_error', __('Could not open CSV file.', 'order-guard-pro'));
        }

        // Skip header row
        fgetcsv($handle);

        $imported = 0;
        $skipped = 0;

        while (($data = fgetcsv($handle)) !== false) {
            if (count($data) < 6) continue;

            $ip = !empty($data[1]) ? sanitize_text_field($data[1]) : null;
            $phone = !empty($data[2]) ? sanitize_text_field($data[2]) : null;
            $email = !empty($data[3]) ? sanitize_email($data[3]) : null;
            $reason = !empty($data[5]) ? sanitize_text_field($data[5]) : '';

            if (!$ip && !$phone && !$email) {
                $skipped++;
                continue;
            }

            if ($this->database->is_blocked($ip, $phone, $email)) {
                $skipped++;
                continue;
            }

            $this->database->block_user($ip, $phone, $email, $reason);
            $imported++;
        }

        fclose($handle);

        return [
            'imported' => $imported,
            'skipped' => $skipped
        ];
    }
}