<?php
class Order_Guard_Pro_Order_Handler {
    private $database;
    private $threshold;
    private $block_duration;
    private $enable_phone_check;
    private $enable_email_check;

    public function __construct($database) {
        $this->database = $database;
        $this->threshold = get_option('order_guard_pro_threshold', 5);
        $this->block_duration = get_option('order_guard_pro_block_duration', 24);
        $this->enable_phone_check = get_option('order_guard_pro_enable_phone_check', '1');
        $this->enable_email_check = get_option('order_guard_pro_enable_email_check', '1');
    }

    public function init() {
        add_action('woocommerce_checkout_process', [$this, 'check_order_attempt']);
        add_action('woocommerce_before_checkout_form', [$this, 'check_if_blocked']);
    }

    public function check_order_attempt() {
        $ip = Order_Guard_Pro_IP_Helper::get_client_ip();
        $phone = $this->enable_phone_check && isset($_POST['billing_phone']) ? sanitize_text_field($_POST['billing_phone']) : null;
        $email = $this->enable_email_check && isset($_POST['billing_email']) ? sanitize_email($_POST['billing_email']) : null;

        if ($this->database->is_whitelisted($ip, $phone, $email)) {
            return;
        }

        if ($this->database->is_blocked($ip, $phone, $email)) {
            $this->show_blocked_message();
        }

        $this->database->log_attempt($ip, $phone, $email, $_POST);

        $recent_attempts = $this->database->get_recent_attempts($ip, $phone, $email, $this->block_duration);

        if ($recent_attempts >= $this->threshold) {
            $this->database->block_user(
                $ip, 
                $phone, 
                $email, 
                sprintf(__('Automatic block after %d order attempts', 'order-guard-pro'), $recent_attempts)
            );
            $this->show_blocked_message();
        }
    }

    public function check_if_blocked() {
        $ip = Order_Guard_Pro_IP_Helper::get_client_ip();
        $phone = $this->enable_phone_check && isset($_POST['billing_phone']) ? sanitize_text_field($_POST['billing_phone']) : null;
        $email = $this->enable_email_check && isset($_POST['billing_email']) ? sanitize_email($_POST['billing_email']) : null;

        if ($this->database->is_blocked($ip, $phone, $email)) {
            $this->show_blocked_message();
        }
    }

    private function show_blocked_message() {
        $message = get_option('order_guard_pro_blocked_message', 
            __('We have detected suspicious order attempts from your information. For security reasons, additional orders cannot be placed at this time.', 'order-guard-pro'));

        wc_add_notice($message, 'error');
        add_filter('woocommerce_order_button_html', '__return_false');
    }
}