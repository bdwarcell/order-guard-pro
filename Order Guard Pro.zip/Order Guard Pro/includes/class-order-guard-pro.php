<?php
class Order_Guard_Pro {
    private $database;
    private $order_handler;
    private $admin_interface;
    private $notifications;
    private $dashboard;

    public function __construct() {
        $this->load_dependencies();
    }

    private function load_dependencies() {
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-database.php';
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-ip-helper.php';
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-order-handler.php';
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-admin-interface.php';
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-export-import.php';
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-notifications.php';
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-dashboard.php';
    }

    public function run() {
        $this->database = new Order_Guard_Pro_Database();
        $this->notifications = new Order_Guard_Pro_Notifications($this->database);
        $this->order_handler = new Order_Guard_Pro_Order_Handler($this->database);
        $this->admin_interface = new Order_Guard_Pro_Admin_Interface($this->database, new Order_Guard_Pro_Export_Import($this->database));
        $this->dashboard = new Order_Guard_Pro_Dashboard($this->database);
        
        $this->database->init();
        $this->notifications->init();
        $this->order_handler->init();
        $this->admin_interface->init();
        $this->dashboard->init();
        
        $this->load_textdomain();
    }

    public function load_textdomain() {
        add_action('init', function() {
            load_plugin_textdomain(
                'order-guard-pro',
                false,
                dirname(plugin_basename(ORDER_GUARD_PRO_PLUGIN_FILE)) . '/languages/'
            );
        });
    }

    public static function activate() {
        require_once ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-database.php';
        Order_Guard_Pro_Database::create_tables();
    }

    public static function deactivate() {
        // Clean up on deactivation if needed
    }
}