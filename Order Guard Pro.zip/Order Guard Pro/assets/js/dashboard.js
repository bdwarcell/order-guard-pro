jQuery(document).ready(function($) {
    // Initialize chart
    var ctx = document.getElementById('order-guard-pro-stats-chart').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: order_guard_pro_dashboard.attempts_label,
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.1)',
                    tension: 0.1,
                    fill: true
                },
                {
                    label: order_guard_pro_dashboard.blocked_label,
                    data: [],
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.1)',
                    tension: 0.1,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: order_guard_pro_dashboard.chart_title
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });

    // Handle date range form submission
    $('#order-guard-pro-date-range-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $button = $form.find('button[type="submit"]');
        var buttonText = $button.text();
        
        $button.prop('disabled', true).text(order_guard_pro_dashboard.loading_text);
        
        var formData = {
            action: 'order_guard_pro_get_stats',
            security: order_guard_pro_dashboard.nonce,
            start_date: $form.find('#start-date').val(),
            end_date: $form.find('#end-date').val()
        };
        
        $.post(order_guard_pro_dashboard.ajax_url, formData, function(response) {
            if (response.success) {
                var data = response.data;
                var labels = [];
                var attemptsData = [];
                var blockedData = [];
                
                // Prepare chart data
                data.attempts.forEach(function(item) {
                    labels.push(item.attempt_date);
                    attemptsData.push(parseInt(item.count));
                });
                
                // Match blocked data with attempts dates
                labels.forEach(function(date) {
                    var found = data.blocked.find(function(item) {
                        return item.attempt_date === date;
                    });
                    blockedData.push(found ? parseInt(found.count) : 0);
                });
                
                // Update chart
                chart.data.labels = labels;
                chart.data.datasets[0].data = attemptsData;
                chart.data.datasets[1].data = blockedData;
                chart.update();
            } else {
                alert(order_guard_pro_dashboard.error_text);
            }
            
            $button.prop('disabled', false).text(buttonText);
        }).fail(function() {
            alert(order_guard_pro_dashboard.error_text);
            $button.prop('disabled', false).text(buttonText);
        });
    });
});