jQuery(document).ready(function($) {
    // Confirm before unblocking or removing
    $(document).on('click', '.order-guard-pro-admin a.button', function(e) {
        if ($(this).text().trim() === wp.i18n.__('Unblock', 'order-guard-pro') || 
            $(this).text().trim() === wp.i18n.__('Remove', 'order-guard-pro')) {
            if (!confirm(wp.i18n.__('Are you sure you want to perform this action?', 'order-guard-pro'))) {
                e.preventDefault();
            }
        }
    });

    // Handle notification dismissal
    $(document).on('click', '.order-guard-pro-notice .notice-dismiss', function() {
        var notice = $(this).closest('.order-guard-pro-notice');
        var notificationId = notice.data('notification-id');
        
        if (notificationId) {
            $.post(ajaxurl, {
                action: 'order_guard_pro_dismiss_notice',
                security: order_guard_pro_admin.nonce,
                notification_id: notificationId
            });
        }
    });
});