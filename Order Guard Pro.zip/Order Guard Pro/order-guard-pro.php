<?php
/**
 * Plugin Name: Order Guard Pro
 * Plugin URI: https://example.com/order-guard-pro
 * Description: Advanced WooCommerce order fraud prevention system
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: order-guard-pro
 * Domain Path: /languages
 * WC requires at least: 3.0.0
 * WC tested up to: 7.0.0
 */

defined('ABSPATH') || exit;

// Define plugin constants
define('ORDER_GUARD_PRO_VERSION', '1.0.0');
define('ORDER_GUARD_PRO_PLUGIN_FILE', __FILE__);
define('ORDER_GUARD_PRO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ORDER_GUARD_PRO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ORDER_GUARD_PRO_BASENAME', plugin_basename(__FILE__));

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'Order_Guard_Pro_';
    
    if (strpos($class, $prefix) === 0) {
        $class_name = str_replace($prefix, '', $class);
        $file_path = ORDER_GUARD_PRO_PLUGIN_DIR . 'includes/class-' . strtolower(str_replace('_', '-', $class_name)) . '.php';
        
        if (file_exists($file_path)) {
            require_once $file_path;
        }
    }
});

// Check if WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', function() {
        echo '<div class="error notice"><p>' . esc_html__('Order Guard Pro requires WooCommerce to be installed and active.', 'order-guard-pro') . '</p></div>';
    });
    return;
}

// Initialize the plugin
function order_guard_pro_init() {
    $plugin = new Order_Guard_Pro();
    $plugin->run();
}
add_action('plugins_loaded', 'order_guard_pro_init');

// Register activation and deactivation hooks
register_activation_hook(__FILE__, ['Order_Guard_Pro', 'activate']);
register_deactivation_hook(__FILE__, ['Order_Guard_Pro', 'deactivate']);