<div class="order-guard-pro-settings-form">
    <form method="post" action="options.php">
        <?php settings_fields('order_guard_pro_settings'); ?>
        <?php do_settings_sections('order-guard-pro'); ?>
        
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><?php esc_html_e('Order Attempt Threshold', 'order-guard-pro'); ?></th>
                <td>
                    <input type="number" name="order_guard_pro_threshold" value="<?php echo esc_attr(get_option('order_guard_pro_threshold', 5)); ?>" min="1" class="small-text" />
                    <p class="description"><?php esc_html_e('Number of order attempts before blocking.', 'order-guard-pro'); ?></p>
                </td>
            </tr>
            
            <tr valign="top">
                <th scope="row"><?php esc_html_e('Block Duration (hours)', 'order-guard-pro'); ?></th>
                <td>
                    <input type="number" name="order_guard_pro_block_duration" value="<?php echo esc_attr(get_option('order_guard_pro_block_duration', 24)); ?>" min="1" class="small-text" />
                    <p class="description"><?php esc_html_e('Hours to look back for order attempts.', 'order-guard-pro'); ?></p>
                </td>
            </tr>
            
            <tr valign="top">
                <th scope="row"><?php esc_html_e('Enable Phone Check', 'order-guard-pro'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="order_guard_pro_enable_phone_check" value="1" <?php checked(1, get_option('order_guard_pro_enable_phone_check', '1')); ?> />
                        <?php esc_html_e('Enable phone number checking', 'order-guard-pro'); ?>
                    </label>
                </td>
            </tr>
            
            <tr valign="top">
                <th scope="row"><?php esc_html_e('Enable Email Check', 'order-guard-pro'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="order_guard_pro_enable_email_check" value="1" <?php checked(1, get_option('order_guard_pro_enable_email_check', '1')); ?> />
                        <?php esc_html_e('Enable email address checking', 'order-guard-pro'); ?>
                    </label>
                </td>
            </tr>
            
            <tr valign="top">
                <th scope="row"><?php esc_html_e('Blocked Message', 'order-guard-pro'); ?></th>
                <td>
                    <textarea name="order_guard_pro_blocked_message" rows="5" class="large-text"><?php echo esc_textarea(get_option('order_guard_pro_blocked_message', __('We have detected suspicious order attempts from your information. For security reasons, additional orders cannot be placed at this time.', 'order-guard-pro'))); ?></textarea>
                    <p class="description"><?php esc_html_e('This message will be shown to blocked users.', 'order-guard-pro'); ?></p>
                </td>
            </tr>
        </table>
        
        <?php submit_button(); ?>
    </form>
</div>