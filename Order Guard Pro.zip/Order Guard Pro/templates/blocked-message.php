<div class="order-guard-pro-blocked-message">
    <div class="order-guard-pro-blocked-content">
        <div class="order-guard-pro-blocked-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#721c24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
        </div>
        
        <h2><?php esc_html_e('Order Blocked', 'order-guard-pro'); ?></h2>
        
        <div class="order-guard-pro-message">
            <p><?php echo esc_html(get_option('order_guard_pro_blocked_message', 
                __('We have detected suspicious order attempts from your information. For security reasons, additional orders cannot be placed at this time.', 'order-guard-pro'))); ?></p>
            <p><?php esc_html_e('If you believe this is an error, please contact our customer support.', 'order-guard-pro'); ?></p>
        </div>
        
        <?php if (is_user_logged_in() && current_user_can('manage_options')) : ?>
            <div class="order-guard-pro-admin-notice">
                <p><strong><?php esc_html_e('Admin Notice:', 'order-guard-pro'); ?></strong> 
                <?php esc_html_e('You are seeing this because you are an admin. Regular users would see a simpler message.', 'order-guard-pro'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.order-guard-pro-blocked-message {
    background-color: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
    padding: 30px;
    margin: 40px 0;
    border-radius: 8px;
    text-align: center;
}

.order-guard-pro-blocked-content {
    max-width: 600px;
    margin: 0 auto;
}

.order-guard-pro-blocked-icon {
    margin-bottom: 20px;
}

.order-guard-pro-blocked-icon svg {
    width: 64px;
    height: 64px;
}

.order-guard-pro-message {
    margin: 20px 0;
    line-height: 1.6;
}

.order-guard-pro-admin-notice {
    background-color: #fff3cd;
    border: 1px solid #ffeeba;
    color: #856404;
    padding: 15px;
    margin-top: 25px;
    border-radius: 4px;
    text-align: left;
}

.order-guard-pro-admin-notice p {
    margin: 0;
}
</style>