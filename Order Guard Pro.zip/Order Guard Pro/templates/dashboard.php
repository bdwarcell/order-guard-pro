<div class="wrap order-guard-pro-dashboard">
    <h1><?php esc_html_e('Order Guard Pro - Dashboard', 'order-guard-pro'); ?></h1>
    
    <div class="order-guard-pro-stats-container">
        <div class="order-guard-pro-stat-card">
            <h3><?php esc_html_e('Today', 'order-guard-pro'); ?></h3>
            <div class="stat-numbers">
                <div class="stat-item">
                    <span class="stat-value"><?php echo number_format($today_attempts); ?></span>
                    <span class="stat-label"><?php esc_html_e('Attempts', 'order-guard-pro'); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo number_format($today_blocked); ?></span>
                    <span class="stat-label"><?php esc_html_e('Blocked', 'order-guard-pro'); ?></span>
                </div>
            </div>
        </div>
        
        <div class="order-guard-pro-stat-card">
            <h3><?php esc_html_e('This Month', 'order-guard-pro'); ?></h3>
            <div class="stat-numbers">
                <div class="stat-item">
                    <span class="stat-value"><?php echo number_format($month_attempts); ?></span>
                    <span class="stat-label"><?php esc_html_e('Attempts', 'order-guard-pro'); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo number_format($month_blocked); ?></span>
                    <span class="stat-label"><?php esc_html_e('Blocked', 'order-guard-pro'); ?></span>
                </div>
            </div>
        </div>
        
        <div class="order-guard-pro-stat-card">
            <h3><?php esc_html_e('This Year', 'order-guard-pro'); ?></h3>
            <div class="stat-numbers">
                <div class="stat-item">
                    <span class="stat-value"><?php echo number_format($year_attempts); ?></span>
                    <span class="stat-label"><?php esc_html_e('Attempts', 'order-guard-pro'); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo number_format($year_blocked); ?></span>
                    <span class="stat-label"><?php esc_html_e('Blocked', 'order-guard-pro'); ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="order-guard-pro-date-range">
        <h2><?php esc_html_e('Custom Date Range Report', 'order-guard-pro'); ?></h2>
        <form id="order-guard-pro-date-range-form">
            <label for="start-date"><?php esc_html_e('Start Date:', 'order-guard-pro'); ?></label>
            <input type="date" id="start-date" name="start_date" required>
            
            <label for="end-date"><?php esc_html_e('End Date:', 'order-guard-pro'); ?></label>
            <input type="date" id="end-date" name="end_date" required>
            
            <button type="submit" class="button button-primary">
                <?php esc_html_e('Generate Report', 'order-guard-pro'); ?>
            </button>
        </form>
        
        <div id="order-guard-pro-chart-container" style="margin-top: 20px;">
            <canvas id="order-guard-pro-stats-chart" width="400" height="200"></canvas>
        </div>
    </div>
</div>