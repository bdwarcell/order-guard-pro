=== Order Guard Pro ===
Contributors: yourname
Tags: woocommerce, fraud prevention, order protection, security
Requires at least: 5.6
Tested up to: 6.0
Stable tag: 1.0.0
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Advanced WooCommerce order fraud prevention system.

== Description ==

Order Guard Pro is a powerful WooCommerce extension designed to prevent fraudulent orders by tracking and blocking suspicious order attempts based on IP address, phone number, and email.

== Features ==

- IP based order attempt tracking
- Phone number verification
- Email address verification
- Automatic blocking after threshold
- Whitelist management
- CSV export/import
- Detailed dashboard and reports
- Customizable blocked message

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/order-guard-pro` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure the plugin settings under WooCommerce > Order Guard Pro
4. Make sure WooCommerce is installed and activated

== Frequently Asked Questions ==

= How does the blocking work? =

The plugin tracks order attempts and blocks users who exceed the configured threshold within the specified time period.

= Can I whitelist certain customers? =

Yes, you can whitelist customers by IP, phone number, or email address in the Whitelist section.

== Screenshots ==

1. Dashboard with order attempt statistics
2. Blocked items management
3. Whitelist management
4. Settings page

== Changelog ==

= 1.0.0 =
* Initial release