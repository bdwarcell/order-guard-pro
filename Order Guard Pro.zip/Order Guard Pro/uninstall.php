<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete options
delete_option('order_guard_pro_threshold');
delete_option('order_guard_pro_block_duration');
delete_option('order_guard_pro_enable_phone_check');
delete_option('order_guard_pro_enable_email_check');
delete_option('order_guard_pro_blocked_message');

// Remove database tables
global $wpdb;

$tables = [
    $wpdb->prefix . 'order_guard_pro_blocked',
    $wpdb->prefix . 'order_guard_pro_attempts',
    $wpdb->prefix . 'order_guard_pro_whitelist',
    $wpdb->prefix . 'order_guard_pro_notifications'
];

foreach ($tables as $table) {
    $wpdb->query("DROP TABLE IF EXISTS $table");
}

// Clear any cached data
wp_cache_flush();